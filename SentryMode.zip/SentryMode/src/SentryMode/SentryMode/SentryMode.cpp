#include "stdafx.h"
#include <xtl.h>
#include <xui.h>    // XUI Runtime
#include <xuiapp.h> // XUI Class Library
#include <string>

const wchar_t* SM_VERSION = L"Version 1.0";

bool doExit = false;
const wchar_t* mode = L"Default";
typedef void (*XNotifyQueueUI)(int _34, int _0, int _2, WCHAR *TEXT, int _0_);
XNotifyQueueUI XNotify = (XNotifyQueueUI)0x816AAC08; //from xam.xex v2.0.17559.0

void setMode() {
	const char* selectedMode;
	if(wcscmp(L"Default", mode) == 0)
		selectedMode = "Default";
	if(wcscmp(L"UART", mode) == 0)
		selectedMode = "UART";
	std::wstring message = L"Sent mode: " + std::wstring(mode);
	printf("[Sentry] %s Mode\n", selectedMode);
	XNotify(34, 0, 2, (WCHAR*)message.c_str(), 0);
}

// Main scene implementation class.
class CMyMainScene : public CXuiSceneImpl
{
protected:
    // Control and Element wrapper objects.
    CXuiControl m_button1;
    CXuiControl m_button2;
    CXuiTextElement m_text1;
	CXuiTextElement m_text2;
	CXuiList m_commonlist;

    // Message map.
    XUI_BEGIN_MSG_MAP()
        XUI_ON_XM_INIT( OnInit )
        XUI_ON_XM_NOTIFY_PRESS( OnNotifyPress )
    XUI_END_MSG_MAP()

    // Handler for the XM_INIT message.
    HRESULT OnInit( XUIMessageInit *pInitData, 
       BOOL& bHandled )
    {
        // Retrieve controls for later use.
        GetChildById( L"XuiButton1", &m_button1 );
        GetChildById( L"XuiButton2", &m_button2 );
        GetChildById( L"XuiText1", &m_text1 );
		GetChildById( L"XuiCommonList1", &m_commonlist );
		GetChildById( L"XuiText4", &m_text2 );
		m_text2.SetText( SM_VERSION );
        return S_OK;
    }

    // Handler for the XM_NOTIFY message
    HRESULT OnNotifyPress( HXUIOBJ hObjPressed, 
       BOOL& bHandled )
    {
		int nIndex;
		if ( hObjPressed == m_commonlist )
		{
			nIndex = m_commonlist.GetCurSel();
			std::wstring labelText = L"Selected Mode: ";
			mode = m_commonlist.GetText(nIndex);
			labelText += mode;
			m_text1.SetText(labelText.c_str());
			
		}
		// Determine which button was pressed,
		// and set the text accordingly.
		if ( hObjPressed == m_button1 )
		{
			setMode();
		}
		else if ( hObjPressed == m_button2 )
		{
			doExit = true;
		}
		else
		{
			return S_OK;
		}
		bHandled = TRUE;
		return S_OK;
    }

public:
    XUI_IMPLEMENT_CLASS( CMyMainScene, L"MyMainScene", 
        XUI_CLASS_SCENE )
};

// declare the main application class
class CMyApp : public CXuiModule
{
protected:
    // Override so that CMyApp can register classes.
    virtual HRESULT RegisterXuiClasses();
    
    // Override so that CMyApp can unregister classes. 
    virtual HRESULT UnregisterXuiClasses();
};

// Register custom classes.
HRESULT CMyApp::RegisterXuiClasses()
{
    return CMyMainScene::Register();
}

// Unregister custom classes.
HRESULT CMyApp::UnregisterXuiClasses()
{
    CMyMainScene::Unregister();
    return S_OK;
}

HRESULT RenderGame( IDirect3DDevice9 *pDevice )
{
    // Render game graphics.
    pDevice->Clear(
        0,
        NULL,
        D3DCLEAR_TARGET | D3DCLEAR_STENCIL | D3DCLEAR_ZBUFFER,
        D3DCOLOR_ARGB( 255, 32, 32, 64 ),
        1.0,
        0 );

    return S_OK;
}

HRESULT InitD3D( IDirect3DDevice9 **ppDevice, 
    D3DPRESENT_PARAMETERS *pd3dPP )
{
    IDirect3D9 *pD3D;

    pD3D = Direct3DCreate9( D3D_SDK_VERSION );

    // Set up the presentation parameters.
    ZeroMemory( pd3dPP, sizeof( D3DPRESENT_PARAMETERS ) );
    pd3dPP->BackBufferWidth        = 1280;
    pd3dPP->BackBufferHeight       = 720;
    pd3dPP->BackBufferFormat       = D3DFMT_A16B16G16R16;
    pd3dPP->BackBufferCount        = 1;
    pd3dPP->MultiSampleType        = D3DMULTISAMPLE_NONE;
    pd3dPP->SwapEffect             = D3DSWAPEFFECT_DISCARD;
    pd3dPP->EnableAutoDepthStencil = TRUE;
    pd3dPP->AutoDepthStencilFormat = D3DFMT_D24S8;
    pd3dPP->PresentationInterval   = D3DPRESENT_INTERVAL_ONE;
    
    // Create the device.
    return pD3D->CreateDevice(
                    0, 
                    D3DDEVTYPE_HAL,
                    NULL,
                    D3DCREATE_HARDWARE_VERTEXPROCESSING,
                    pd3dPP,
                    ppDevice );
}

// Entry point of the title.
int __cdecl main()
{
    IDirect3DDevice9 *pDevice;
    D3DPRESENT_PARAMETERS d3dpp;
    HRESULT hr;

    // Initialize D3D
    hr = InitD3D( &pDevice, &d3dpp );
    if( FAILED(hr) ) {
        OutputDebugString
            ( "Failed initializing D3D.\n" );
    }

    // Declare an instance of the XUI framework.
    CMyApp app;

    // Initialize the application.
    hr = app.InitShared( pDevice, &d3dpp, 
        XuiD3DXTextureLoader );

    if ( FAILED(hr) )
    {
        OutputDebugString
            ( "Failed initializing application.\n" );
        return 1;
    }


    // Load the skin file used for the scene.
	app.LoadSkin( L"file://game:/ui.xzp#XUI\\simple_scene_skin.xur" );

    // Register the font. 
    app.RegisterDefaultTypeface( L"Arial Unicode MS", 
        L"file://game:/ui.xzp#XUI\\xarialuni.ttf" ); 

    // Load the scene.
    app.LoadFirstScene( L"file://game:/", 
        L"ui.xzp#XUI\\simple_scene.xur", NULL );
    

    while( !doExit ) {
        // Render game graphics.
        RenderGame( pDevice );
    
        // Update XUI
        app.RunFrame();

        // Render XUI
        hr = app.Render();

        // Update XUI Timers
        hr = XuiTimersRun();

        // Present the frame.
        pDevice->Present( NULL, NULL, NULL, NULL );
    }

    // Free resources, unregister custom classes, and exit.
    app.Uninit();
    pDevice->Release();
}
